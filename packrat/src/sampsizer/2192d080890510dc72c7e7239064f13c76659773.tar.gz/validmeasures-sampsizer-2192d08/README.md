<!-- README.md is generated from README.Rmd. Please edit that file -->
sampsizer: An Implementation of Sample Size Equations for Calculating Various Estimators in R
=============================================================================================

[![Travis-CI Build
Status](https://travis-ci.org/validmeasures/sampsizer.svg?branch=master)](https://travis-ci.org/validmeausures/sampsizer)
[![AppVeyor Build
Status](https://ci.appveyor.com/api/projects/status/github/validmeasures/sampsizer?branch=master&svg=true)](https://ci.appveyor.com/project/validmeasures/sampsizer)
[![Coverage
Status](https://img.shields.io/codecov/c/github/validmeasures/sampsizer/master.svg)](https://codecov.io/github/validmeasures/sampsizer?branch=master)
