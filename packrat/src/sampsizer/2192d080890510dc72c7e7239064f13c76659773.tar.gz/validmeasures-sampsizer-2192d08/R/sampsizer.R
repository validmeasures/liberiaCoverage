################################################################################
#
#' sampsizer
#'
#' Calculate sample sizes for various survey settings and conditions.
#'
#' @docType package
#' @name sampsizer
#'
#' @importFrom Hmisc deff
#
################################################################################
NULL
