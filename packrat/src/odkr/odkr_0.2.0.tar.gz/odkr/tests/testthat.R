library(testthat)
library(odkr)

test_check("odkr")
