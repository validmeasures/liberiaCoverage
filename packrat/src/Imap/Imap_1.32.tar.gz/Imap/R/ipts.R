ipts <- function (longlat=npacific, axes = 'std', ...)
{
    imap(longlat, type = 'p', axes = axes, fill = FALSE, ...)
     
}

