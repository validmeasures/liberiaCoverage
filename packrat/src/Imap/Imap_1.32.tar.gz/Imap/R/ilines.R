ilines <- function (..., fill = FALSE, aspect = 2) 
 {
    imap(..., fill = fill, aspect = aspect)
 }


