library(testthat)
library(bbw)

test_check("bbw")
