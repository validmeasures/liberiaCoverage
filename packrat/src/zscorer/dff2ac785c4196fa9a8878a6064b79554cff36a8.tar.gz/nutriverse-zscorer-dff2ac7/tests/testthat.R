library(testthat)
library(zscorer)

test_check("zscorer")
